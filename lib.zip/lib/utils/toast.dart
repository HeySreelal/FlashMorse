import 'package:fluttertoast/fluttertoast.dart';

void showMsg(String msg) {
  Fluttertoast.showToast(msg: msg);
}
